
public interface Actions {
public void Login();
public void Register();
}
